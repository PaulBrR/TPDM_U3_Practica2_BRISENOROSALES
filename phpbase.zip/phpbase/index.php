<?php

echo "Estas en la pagina principal de Paul";

?>