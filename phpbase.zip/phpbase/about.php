<?php

echo "(C) paul briseno";

?>