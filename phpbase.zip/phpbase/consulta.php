<?php
$con=mysqli_connect('us-cdbr-iron-east-05.cleardb.net','b5e0301b7e9570','e8403352','heroku_20fdad269f45aa5');


if(!$con){
	echo "NO SE CONECTO";
	return;
}

$id = $_POST["id"];


$SQL = "SELECT * FROM eventos WHERE id =$id";

$respuesta = mysqli_query($con,$SQL);


$renglon = mysqli_fetch_row($respuesta);
if($renglon){
	
		echo "id: $renglon[0], desc: $renglon[1], Fecha: $renglon[2], Lugar: $renglon[3]";

	}

}else{
	echo "no hay data a mostrar";
}



?>