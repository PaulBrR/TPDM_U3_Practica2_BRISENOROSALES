<?php
	//comentario de 1 linea
	/*
		comentario de varias lineas

	*/
		$numero = 90;

		$nom = $_POST["nombrecompleto"];
		$e = $_POST['edad'];
		$sueldo = $_POST['sueldo'];

		//echo "Datos recuperados: $nom, $e y sueldo $sueldo";


		if ($sueldo > 30000) {
    echo "Ganas bastante bien amigo";
} else{
    echo "Ya comiste?";
}



		// if si sueldo es mayor a 30 mil ganas bastante bien si es menor te ponga ya  comiste mysql://b5e0301b7e9570:e8403352@us-cdbr-iron-east-05.cleardb.net/heroku_20fdad269f45aa5?reconnect=true




?>