<?php	
//mysqli_conncet('host','user','password','basededatos');
$con=mysqli_connect('us-cdbr-iron-east-05.cleardb.net','b5e0301b7e9570','e8403352','heroku_20fdad269f45aa5');

if(!$con){
	echo "NO SE CONECTO";
	return;
}
//mysql://:@/

//Obteniendo variables desde el formulario

$DESCRIPCION = $_POST['DESCRIPCION'];
$MONTO = $_POST['MONTO'];
$FECHAVENCIMIENTO = $_POST['FECHAVENCIMIENTO'];
$PAGADO= $_POST['PAGADO'];

$SQL = "INSERT INTO RECIBOAPAGOS(DESCRIPCION,MONTO,FECHAVENCIMIENTO,PAGADO) values('$DESCRIPCION','$MONTO','$FECHAVENCIMIENTO','$PAGADO')";

//mysqli_query(CONEXION,Cadena SQL)

$respuesta = mysqli_query($con , $SQL);
if($respuesta){
	echo "si se capturo";
}else{echo "Error se murio"; 
}

?>