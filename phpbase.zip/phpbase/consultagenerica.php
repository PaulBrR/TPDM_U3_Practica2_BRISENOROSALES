<?php
$con = mysqli_connect('us-cdbr-iron-east-05.cleardb.net','b5e0301b7e9570','e8403352','heroku_20fdad269f45aa5');


if(!$con){
	echo "NO SE CONECTO";
	return;
}
$SQL = "SELECT * FROM eventos";

$respuesta = mysqli_query($con, $SQL);

$numRenglones = mysqli_num_rows($respuesta);
if($numRenglones>0){
	while ($renglon = $respuesta->fetch_object()) {//recorta las tuplas ,fetch es el corte
		$data[] = $renglon;
	}
	echo (json_encode($data));
		
	}else{
	echo "no hay data a mostrar";
}

/*$renglon = mysqli_fetch_row($respuesta);
if($renglon){
	do{
		echo "id: $renglon[0], desc: $renglon[1], Fecha: $renglon[2], Lugar: $renglon[3]";

	}while ($renglon); */



?>