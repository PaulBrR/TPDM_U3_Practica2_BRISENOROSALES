<?php	
//mysqli_conncet('host','user','password','basededatos');
$con=mysqli_connect('us-cdbr-iron-east-05.cleardb.net','b5e0301b7e9570','e8403352','heroku_20fdad269f45aa5');


if(!$con){
	echo "NO SE CONECTO";
	return;
}
//mysql://:@/

//Obteniendo variables desde el formulario

$ID = $_POST ['ID'];

$SQL = "DELETE FROM RECIBOAPAGO WHERE ID=$ID";

//mysqli_query(CONEXION,Cadena SQL)
$respuesta = mysqli_query($con,$SQL);
if($respuesta){
	echo "si se elimino";
}else{echo "no se elimono"};


?>